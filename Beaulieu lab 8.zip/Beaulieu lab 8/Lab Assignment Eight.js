var img1;
var img2;
var gif1;
var quote = "slow saturday vibes";
let howdy;
function preload(){
	img1 = loadImage("WideTom.jpg");
	img2 = loadImage("WashingMachine.jpg");
	gif1 = loadImage("Jefferson.gif");
	howdy = loadFont("Chango-Regular.ttf");
}
function setup(){
	createCanvas(1900, 900);
	background(51);
	textFont("howdy");
	colorMode(RGB, 255, 255, 255, 1);
}
function draw(){
	image(img1, mouseX, mouseY);
	image(img2, 0, 0);
	image(gif1, 900, 0);
	textSize(45);
	strokeWeight(4);
	stroke(0);
	fill(255, 0, 255, 0.9);
	text(quote, 20, 10, 400, 300);
}