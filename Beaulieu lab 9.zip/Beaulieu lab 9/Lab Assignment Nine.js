//var e;
var Howdy;
var capture;
var quote = "Professional Gamer";
let mic;
function preload(){
	e = loadImage("Jefferson.gif");
	ok = loadImage("ickyman.gif");
	Howdy = loadSound("Down The Hatch.m4a");
}
function setup(){
	let cnv = createCanvas(1900, 800);
	cnv.mousePressed(userStartAudio);
	background(51);
	capture = createCapture();
	capture.hide();
	colorMode(RGB, 255, 255, 255, 1);
	mic = new p5.AudioIn();
	mic.start();
}
function mousePressed(){
	Howdy.play();
}

function draw() {
	micLevel = mic.getLevel();
	let y = height - micLevel * height;
	var aspectRatio = capture.height/capture.width;
	var h = width * aspectRatio;
	image(capture, 0, 200, 1900, 300);
	filter(GRAY);
	image(e, 1100, 30);
	image(ok, y, 600);
	textSize(45);
	strokeWeight(4);
	stroke(0);
	fill(255, 0, 255, 0.9);
	text(quote, 600, 550, 1000, 800);
}
