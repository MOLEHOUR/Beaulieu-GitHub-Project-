let yes;
function setup(){
	noCanvas();
	yes = createVideo(
	  ['The Hut.mp4', 'The-Hut.ogv', 'The Hut.webm'],
	  vidLoad
	);
	yes.size(320, 240);
}
function vidLoad(){
	yes.loop();
 	yes.showControls();
 	yes.volume(0);
 	yes.play();
}